// =====================================
// AGENTPRO - MAIN APPLICATION
// =====================================

import {
    initializeStorage,
    getSession
} from "./storage.js";

import {
    checkAuthentication,
    logout
} from "./auth.js";

import {
    initializeNavigation,
    navigateTo
} from "./navigation.js";

initializeStorage();

// Protect dashboard
if (!checkAuthentication()) {

    throw new Error("Authentication required");

}

// Initialize dashboard navigation
initializeNavigation();

// Display logged-in administrator
const session = getSession();

const profile = document.querySelector(".admin-profile");

if (profile && session) {

    profile.innerHTML = `

        <div class="avatar">
            ${session.name.charAt(0).toUpperCase()}
        </div>

        <div>
            <strong>${session.name}</strong>
            <small>${session.role}</small>
        </div>

    `;

}

// Logout button
const logoutButton = document.getElementById("logoutBtn");

if (logoutButton) {

    logoutButton.addEventListener("click", event => {

        event.preventDefault();

        logout();

    });

}

// Dark mode
const themeToggle = document.getElementById("themeToggle");

if (themeToggle) {

    const savedTheme = localStorage.getItem("agentpro_theme");

    if (savedTheme === "dark") {
        document.body.classList.add("dark-mode");
    }

    themeToggle.addEventListener("click", event => {

        event.preventDefault();

        document.body.classList.toggle("dark-mode");

        const isDark = document.body.classList.contains("dark-mode");

        localStorage.setItem(
            "agentpro_theme",
            isDark ? "dark" : "light"
        );

    });

}

// Initial page
navigateTo("dashboard");

console.log("AgentPro initialized successfully.");