// =====================================
// AGENTPRO - AUTHENTICATION
// =====================================

import {
    initializeStorage,
    getData,
    saveData,
    setSession,
    getSession,
    clearSession
} from "./storage.js";

import {
    validateEmail,
    validatePassword,
    validateRequired
} from "./utils/validation.js";

initializeStorage();

// LOGIN
const loginForm = document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const email = document.getElementById("loginEmail").value.trim();
        const password = document.getElementById("loginPassword").value;

        const message = document.getElementById("loginMessage");

        if (!validateEmail(email)) {
            message.textContent = "Enter a valid email address.";
            message.style.color = "red";
            return;
        }

        const users = getData("users");

        const user = users.find(item =>
            item.email.toLowerCase() === email.toLowerCase() &&
            item.password === password
        );

        if (!user) {

            message.textContent = "Invalid email or password.";
            message.style.color = "red";

            return;
        }

        setSession({
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role
        });

        window.location.href = "index.html";

    });

}


// REGISTER
const registerForm = document.getElementById("registerForm");

if (registerForm) {

    registerForm.addEventListener("submit", function(event) {

        event.preventDefault();

        const name = document.getElementById("registerName").value.trim();

        const email = document.getElementById("registerEmail").value.trim();

        const password = document.getElementById("registerPassword").value;

        const confirmPassword = document.getElementById("confirmPassword").value;

        const message = document.getElementById("registerMessage");

        if (!validateRequired(name)) {
            message.textContent = "Enter your name.";
            message.style.color = "red";
            return;
        }

        if (!validateEmail(email)) {
            message.textContent = "Enter a valid email.";
            message.style.color = "red";
            return;
        }

        if (!validatePassword(password)) {
            message.textContent = "Password must contain at least 6 characters.";
            message.style.color = "red";
            return;
        }

        if (password !== confirmPassword) {
            message.textContent = "Passwords do not match.";
            message.style.color = "red";
            return;
        }

        const users = getData("users");

        const existingUser = users.find(user =>
            user.email.toLowerCase() === email.toLowerCase()
        );

        if (existingUser) {
            message.textContent = "Email already registered.";
            message.style.color = "red";
            return;
        }

        const newUser = {
            id: "USR" + Date.now(),
            name,
            email,
            password,
            role: "admin"
        };

        users.push(newUser);

        saveData("users", users);

        message.textContent = "Registration successful! Redirecting...";
        message.style.color = "green";

        setTimeout(() => {
            window.location.href = "login.html";
        }, 1500);

    });

}


// LOGOUT
export function logout() {

    clearSession();

    window.location.href = "login.html";

}

// SESSION CHECK
export function checkAuthentication() {

    const session = getSession();

    if (!session) {

        window.location.href = "login.html";

        return false;
    }

    return true;

}