// =====================================
// AGENTPRO - STORAGE MANAGEMENT
// =====================================

import { initialAgents } from "../data/agents.js";
import { initialCommissions } from "../data/commissions.js";
import { initialTraining } from "../data/training.js";
import { initialIncentives } from "../data/incentives.js";

const STORAGE_KEYS = {
    agents: "agentpro_agents",
    commissions: "agentpro_commissions",
    training: "agentpro_training",
    incentives: "agentpro_incentives",
    users: "agentpro_users",
    session: "agentpro_session"
};

// Get stored data
export function getData(key) {
    try {
        const data = localStorage.getItem(STORAGE_KEYS[key]);
        return data ? JSON.parse(data) : [];
    } catch (error) {
        console.error("Storage error:", error);
        return [];
    }
}

// Save data
export function saveData(key, data) {
    localStorage.setItem(
        STORAGE_KEYS[key],
        JSON.stringify(data)
    );
}

// Initialize sample data
export function initializeStorage() {

    const defaults = {
        agents: initialAgents,
        commissions: initialCommissions,
        training: initialTraining,
        incentives: initialIncentives,
        users: [{
            id: "USR001",
            name: "Administrator",
            email: "admin@agentpro.com",
            password: "admin123",
            role: "admin"
        }]
    };

    Object.entries(defaults).forEach(([key, value]) => {

        if (!localStorage.getItem(STORAGE_KEYS[key])) {
            saveData(key, value);
        }

    });
}

// Agent functions
export function getAgents() {
    return JSON.parse(
        localStorage.getItem("agents") || "[]"
    );
}

export function addAgent(agent) {
    const agents = getAgents();

    agents.push(agent);

    localStorage.setItem("agents", JSON.stringify(agents));

    return agent;
}

export function updateAgent(id, updatedAgent) {
    const agents = getAgents();

    const index = agents.findIndex(agent => agent.id === id);

    if (index === -1) return false;

    agents[index] = updatedAgent;

    localStorage.setItem("agents", JSON.stringify(agents));

    return true;
}

export function deleteAgent(id) {
    const agents = getAgents().filter(agent => agent.id !== id);

    localStorage.setItem("agents", JSON.stringify(agents));
}
// Commission functions
export function getCommissions() {
    return getData("commissions");
}

export function saveCommissions(data) {
    saveData("commissions", data);
}

// Training functions
export function getTraining() {
    return getData("training");
}

export function saveTraining(data) {
    saveData("training", data);
}

// Incentive functions
export function getIncentives() {
    return getData("incentives");
}

export function saveIncentives(data) {
    saveData("incentives", data);
}

// Authentication session
export function setSession(user) {

    localStorage.setItem(
        STORAGE_KEYS.session,
        JSON.stringify(user)
    );

}

export function getSession() {

    try {
        return JSON.parse(
            localStorage.getItem(STORAGE_KEYS.session)
        );
    } catch {
        return null;
    }

}

export function clearSession() {
    localStorage.removeItem(STORAGE_KEYS.session);
}