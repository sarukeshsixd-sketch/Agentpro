// =====================================
// AGENTPRO - NAVIGATION
// =====================================

import { renderDashboard } from "./modules/dashboard.js";
import { renderAgents } from "./modules/agents.js";
import { renderCommissions } from "./modules/commissions.js";
import { renderPerformance } from "./modules/performance.js";
import { renderTraining } from "./modules/training.js";
import { renderIncentives } from "./modules/incentives.js";
import { renderReports } from "./modules/reports.js";

const pages = {

    dashboard: renderDashboard,

    agents: renderAgents,

    commissions: renderCommissions,

    performance: renderPerformance,

    training: renderTraining,

    incentives: renderIncentives,

    reports: renderReports

};

export function navigateTo(page) {

    const pageContent = document.getElementById("pageContent");

    const pageTitle = document.getElementById("pageTitle");

    if (!pages[page]) {
        pageContent.innerHTML = "<h2>Page not found</h2>";
        return;
    }

    document.querySelectorAll(".nav-link[data-page]").forEach(link => {

        link.classList.toggle(
            "active",
            link.dataset.page === page
        );

    });

    pageTitle.textContent =
        page.charAt(0).toUpperCase() + page.slice(1);

    pages[page]();

}

export function initializeNavigation() {

    document.addEventListener("click", event => {

        const link = event.target.closest("[data-page]");

        if (!link) return;

        event.preventDefault();

        navigateTo(link.dataset.page);

    });

}