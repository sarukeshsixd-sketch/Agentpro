import {
    getIncentives,
    saveIncentives,
    getAgents
} from "../storage.js";

import {
    generateID,
    escapeHTML,
    formatCurrency,
    formatDate,
    showNotification
} from "../utils/helpers.js";

export function renderIncentives() {
    document.getElementById("pageContent").innerHTML = `
        <div class="page-header">
            <div>
                <h1>Incentives & Rewards</h1>
                <p>Recognize and reward agent achievements.</p>
            </div>
        </div>

        <div class="panel">
            <h3>Create Incentive</h3>

            <form id="incentiveForm">
                <label>Incentive Title</label>
                <input type="text" id="incentiveTitle" required>

                <label>Select Agent</label>
                <select id="incentiveAgent" required>
                    <option value="">Select Agent</option>
                    ${getAgents().map(agent => `
                        <option value="${escapeHTML(agent.id)}">
                            ${escapeHTML(agent.name)}
                        </option>
                    `).join("")}
                </select>

                <label>Reward Amount (₹)</label>
                <input type="number" id="rewardAmount"
                    min="1" required>

                <label>Reward Date</label>
                <input type="date" id="rewardDate" required>

                <button type="submit" class="btn-primary">
                    Add Incentive
                </button>
            </form>
        </div>

        <div class="panel">
            <h3>Incentive History</h3>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Incentive</th>
                            <th>Agent</th>
                            <th>Reward</th>
                            <th>Date</th>
                        </tr>
                    </thead>

                    <tbody id="incentiveTable"></tbody>
                </table>
            </div>
        </div>
    `;

    displayIncentives();

    document.getElementById("incentiveForm")
        .addEventListener("submit", addIncentive);
}

function displayIncentives() {
    const incentives = getIncentives();
    const agents = getAgents();

    document.getElementById("incentiveTable").innerHTML =
        incentives.length
        ? incentives.map(item => {
            const agent = agents.find(a => a.id === item.agentId);

            return `
                <tr>
                    <td>${escapeHTML(item.title)}</td>
                    <td>${escapeHTML(agent?.name || "Unknown")}</td>
                    <td>${formatCurrency(item.amount)}</td>
                    <td>${formatDate(item.date)}</td>
                </tr>
            `;
        }).join("")
        : `<tr><td colspan="4">No incentives recorded.</td></tr>`;
}

function addIncentive(event) {
    event.preventDefault();

    const incentives = getIncentives();

    const amount = Number(
        document.getElementById("rewardAmount").value
    );

    if (amount <= 0) {
        showNotification("Enter a valid reward amount.", "error");
        return;
    }

    incentives.push({
        id: generateID("INC"),
        title: document.getElementById("incentiveTitle").value.trim(),
        agentId: document.getElementById("incentiveAgent").value,
        amount,
        date: document.getElementById("rewardDate").value,
        createdAt: new Date().toISOString()
    });

    saveIncentives(incentives);

    showNotification("Incentive added successfully.");
    renderIncentives();
}