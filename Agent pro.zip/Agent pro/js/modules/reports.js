import {
    getAgents,
    getCommissions,
    getTraining,
    getIncentives
} from "../storage.js";

import {
    formatCurrency
} from "../utils/helpers.js";

export function renderReports() {
    const agents = getAgents();
    const commissions = getCommissions();
    const training = getTraining();
    const incentives = getIncentives();

    const totalCommission = commissions.reduce(
        (sum, item) => sum + Number(item.amount || 0), 0
    );

    const paidCommission = commissions
        .filter(item => item.status === "Paid")
        .reduce((sum, item) => sum + Number(item.amount || 0), 0);

    const totalPolicies = agents.reduce(
        (sum, agent) => sum + Number(agent.policiesSold || 0), 0
    );

    document.getElementById("pageContent").innerHTML = `
        <div class="page-header">
            <div>
                <h1>Reports & Analytics</h1>
                <p>View business summaries and export reports.</p>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <span>Total Agents</span>
                <h2>${agents.length}</h2>
            </div>

            <div class="stat-card">
                <span>Total Policies</span>
                <h2>${totalPolicies}</h2>
            </div>

            <div class="stat-card">
                <span>Total Commission</span>
                <h2>${formatCurrency(totalCommission)}</h2>
            </div>

            <div class="stat-card">
                <span>Paid Commission</span>
                <h2>${formatCurrency(paidCommission)}</h2>
            </div>
        </div>

        <div class="panel">
            <h3>Export Reports</h3>

            <p>Download your AgentPro records as CSV files.</p>

            <button class="btn-primary" id="exportAgents">
                Export Agents
            </button>

            <button class="btn-primary" id="exportCommissions">
                Export Commissions
            </button>

            <button class="btn-primary" id="exportTraining">
                Export Training
            </button>

            <button class="btn-primary" id="exportIncentives">
                Export Incentives
            </button>

            <button class="btn-small" id="printReport">
                Print Report
            </button>
        </div>
    `;

    document.getElementById("exportAgents").onclick = () =>
        downloadCSV("agents.csv", agents);

    document.getElementById("exportCommissions").onclick = () =>
        downloadCSV("commissions.csv", commissions);

    document.getElementById("exportTraining").onclick = () =>
        downloadCSV("training.csv", training);

    document.getElementById("exportIncentives").onclick = () =>
        downloadCSV("incentives.csv", incentives);

    document.getElementById("printReport").onclick = () =>
        window.print();
}

function downloadCSV(filename, data) {
    if (!data.length) {
        alert("No data available to export.");
        return;
    }

    const headers = [...new Set(
        data.flatMap(item => Object.keys(item))
    )];

    const escapeCSV = value => {
        const text = String(value ?? "");
        return `"${text.replace(/"/g, '""')}"`;
    };

    const rows = [
        headers.map(escapeCSV).join(","),
        ...data.map(item =>
            headers.map(header => escapeCSV(item[header])).join(",")
        )
    ];

    const csv = rows.join("\n");

    const blob = new Blob([csv], {
        type: "text/csv;charset=utf-8;"
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = filename;

    document.body.appendChild(link);
    link.click();
    link.remove();

    URL.revokeObjectURL(url);
}