import {
    getTraining,
    saveTraining
} from "../storage.js";

import {
    generateID,
    escapeHTML,
    formatDate,
    showNotification
} from "../utils/helpers.js";

export function renderTraining() {
    const training = getTraining();

    document.getElementById("pageContent").innerHTML = `
        <div class="page-header">
            <div>
                <h1>Training Management</h1>
                <p>Create and manage agent training programs.</p>
            </div>
        </div>

        <div class="panel">
            <h3>Create Training Program</h3>

            <form id="trainingForm">
                <label>Training Title</label>
                <input type="text" id="trainingTitle" required>

                <label>Description</label>
                <textarea id="trainingDescription" required></textarea>

                <label>Training Date</label>
                <input type="date" id="trainingDate" required>

                <label>Trainer Name</label>
                <input type="text" id="trainerName" required>

                <button type="submit" class="btn-primary">
                    Add Training
                </button>
            </form>
        </div>

        <div class="panel">
            <h3>Available Training Programs</h3>

            <div class="training-list" id="trainingList"></div>
        </div>
    `;

    displayTraining();

    document.getElementById("trainingForm")
        .addEventListener("submit", addTraining);
}

function displayTraining() {
    const training = getTraining();

    document.getElementById("trainingList").innerHTML =
        training.length
        ? training.map(item => `
            <div class="training-card">
                <h3>${escapeHTML(item.title)}</h3>
                <p>${escapeHTML(item.description)}</p>
                <p><strong>Trainer:</strong> ${escapeHTML(item.trainer)}</p>
                <p><strong>Date:</strong> ${formatDate(item.date)}</p>
            </div>
        `).join("")
        : "<p>No training programs available.</p>";
}

function addTraining(event) {
    event.preventDefault();

    const training = getTraining();

    training.push({
        id: generateID("TRN"),
        title: document.getElementById("trainingTitle").value.trim(),
        description: document.getElementById("trainingDescription").value.trim(),
        date: document.getElementById("trainingDate").value,
        trainer: document.getElementById("trainerName").value.trim(),
        createdAt: new Date().toISOString()
    });

    saveTraining(training);

    showNotification("Training program added.");
    renderTraining();
}