import { getAgents } from "../storage.js";

import {
    calculatePercentage,
    escapeHTML
} from "../utils/helpers.js";

export function renderPerformance() {
    const agents = [...getAgents()].sort(
        (a, b) => Number(b.policiesSold || 0) -
                  Number(a.policiesSold || 0)
    );

    const defaultTarget = 20;

    document.getElementById("pageContent").innerHTML = `
        <div class="page-header">
            <div>
                <h1>Performance Tracking</h1>
                <p>Monitor agent targets and achievements.</p>
            </div>
        </div>

        <div class="panel">
            <h3>Agent Performance Overview</h3>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Agent</th>
                            <th>Policies Sold</th>
                            <th>Target</th>
                            <th>Achievement</th>
                            <th>Performance</th>
                        </tr>
                    </thead>

                    <tbody>
                        ${
                            agents.length
                            ? agents.map((agent, index) => {
                                const sold = Number(agent.policiesSold || 0);
                                const target = Number(agent.target || defaultTarget);
                                const percentage = calculatePercentage(sold, target);

                                let level = "Needs Improvement";

                                if (percentage >= 100) level = "Excellent";
                                else if (percentage >= 75) level = "Good";
                                else if (percentage >= 50) level = "Average";

                                return `
                                    <tr>
                                        <td>#${index + 1}</td>
                                        <td>${escapeHTML(agent.name)}</td>
                                        <td>${sold}</td>
                                        <td>${target}</td>
                                        <td>${percentage}%</td>
                                        <td>${level}</td>
                                    </tr>
                                `;
                            }).join("")
                            : `<tr><td colspan="6">No agents available.</td></tr>`
                        }
                    </tbody>
                </table>
            </div>
        </div>
    `;
}