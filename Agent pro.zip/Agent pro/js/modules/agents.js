import {
    getAgents,
    addAgent,
    updateAgent,
    deleteAgent
} from "../storage.js";

import {
    generateID,
    escapeHTML,
    formatCurrency,
    showNotification
} from "../utils/helpers.js";

import {
    validateAgent
} from "../utils/validation.js";

export function renderAgents() {
    const agents = getAgents();

    document.getElementById("pageContent").innerHTML = `
        <div class="page-header">
            <div>
                <h1>Agent Management</h1>
                <p>Manage and monitor insurance agents.</p>
            </div>

            <button class="btn-primary" id="addAgentBtn">
                + Add Agent
            </button>
        </div>

        <div class="panel">
            <div class="filters">
                <input
                    type="text"
                    id="agentSearch"
                    placeholder="Search by name or email..."
                >

                <select id="statusFilter">
                    <option value="">All Statuses</option>
                    <option value="Active">Active</option>
                    <option value="Inactive">Inactive</option>
                </select>
            </div>

            <div id="agentFormContainer"></div>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Location</th>
                            <th>Policies</th>
                            <th>Commission</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody id="agentsTableBody"></tbody>
                </table>
            </div>
        </div>
    `;

    displayAgents(agents);

    document.getElementById("addAgentBtn")
        .addEventListener("click", () => showAgentForm());

    document.getElementById("agentSearch")
        .addEventListener("input", filterAgents);

    document.getElementById("statusFilter")
        .addEventListener("change", filterAgents);

    document.getElementById("agentsTableBody")
        .addEventListener("click", handleAgentAction);
}

function displayAgents(agents) {
    const tbody = document.getElementById("agentsTableBody");

    tbody.innerHTML = agents.length
        ? agents.map(agent => `
            <tr>
                <td>${escapeHTML(agent.name)}</td>
                <td>${escapeHTML(agent.email)}</td>
                <td>${escapeHTML(agent.location || "-")}</td>
                <td>${Number(agent.policiesSold || 0)}</td>
                <td>${formatCurrency(agent.commission || 0)}</td>
                <td>
                    <span class="badge">
                        ${escapeHTML(agent.status)}
                    </span>
                </td>
                <td>
                    <button class="btn-small"
                        data-action="edit"
                        data-id="${escapeHTML(agent.id)}">
                        Edit
                    </button>

                    <button class="btn-small"
                        data-action="view"
                        data-id="${escapeHTML(agent.id)}">
                        View
                    </button>

                    <button class="btn-small"
                        data-action="delete"
                        data-id="${escapeHTML(agent.id)}">
                        Delete
                    </button>
                </td>
            </tr>
        `).join("")
        : `<tr><td colspan="7">No agents found.</td></tr>`;
}

function filterAgents() {
    const search = document.getElementById("agentSearch")
        .value.toLowerCase();

    const status = document.getElementById("statusFilter").value;

    const filtered = getAgents().filter(agent => {
        const matchesSearch =
            agent.name.toLowerCase().includes(search) ||
            agent.email.toLowerCase().includes(search);

        const matchesStatus =
            !status || agent.status === status;

        return matchesSearch && matchesStatus;
    });

    displayAgents(filtered);
}

function showAgentForm(agent = null) {
    const container = document.getElementById("agentFormContainer");

    container.innerHTML = `
        <div class="form-panel">
            <h3>${agent ? "Edit Agent" : "Register New Agent"}</h3>

            <form id="agentForm">
                <input type="hidden" id="agentId"
                    value="${escapeHTML(agent?.id || "")}">

                <label>Full Name</label>
                <input type="text" id="agentName"
                    value="${escapeHTML(agent?.name || "")}" required>

                <label>Email</label>
                <input type="email" id="agentEmail"
                    value="${escapeHTML(agent?.email || "")}" required>

                <label>Phone</label>
                <input type="tel" id="agentPhone"
                    value="${escapeHTML(agent?.phone || "")}" required>

                <label>Location</label>
                <input type="text" id="agentLocation"
                    value="${escapeHTML(agent?.location || "")}" required>

                <label>Status</label>
                <select id="agentStatus">
                    <option value="Active"
                        ${agent?.status === "Active" ? "selected" : ""}>
                        Active
                    </option>

                    <option value="Inactive"
                        ${agent?.status === "Inactive" ? "selected" : ""}>
                        Inactive
                    </option>
                </select>

                <button type="submit" class="btn-primary">
                    ${agent ? "Update Agent" : "Save Agent"}
                </button>

                <button type="button" id="cancelAgentForm"
                    class="btn-small">
                    Cancel
                </button>
            </form>
        </div>
    `;

    document.getElementById("agentForm")
        .addEventListener("submit", saveAgentForm);

    document.getElementById("cancelAgentForm")
        .addEventListener("click", () => {
            container.innerHTML = "";
        });
}

function saveAgentForm(event) {
    event.preventDefault();

    const id = document.getElementById("agentId").value;

    const name = document.getElementById("agentName").value.trim();
    const email = document.getElementById("agentEmail").value.trim();
    const phone = document.getElementById("agentPhone").value.trim();
    const location = document.getElementById("agentLocation").value.trim();
    const status = document.getElementById("agentStatus").value;

    // Validate fields
    if (!name || !email || !phone || !location) {
        alert("Please fill in all fields.");
        return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        alert("Please enter a valid email address.");
        return;
    }

    if (!/^[6-9]\d{9}$/.test(phone)) {
        alert("Enter a valid 10-digit Indian mobile number.");
        return;
    }

    // Check duplicate email
    const agents = getAgents();

    const duplicate = agents.some(agent =>
        agent.email.toLowerCase() === email.toLowerCase() &&
        agent.id !== id
    );

    if (duplicate) {
        alert("This email is already registered.");
        return;
    }

    const agent = {
        id: id || generateID("AGT"),
        name,
        email,
        phone,
        location,
        status,
        policiesSold: 0,
        commission: 0,
        performance: 0,
        target: 20,
        createdAt: new Date().toISOString()
    };

    try {
        if (id) {
            const existing = agents.find(item => item.id === id);

            agent.policiesSold = existing?.policiesSold || 0;
            agent.commission = existing?.commission || 0;
            agent.performance = existing?.performance || 0;

            updateAgent(id, agent);
        } else {
            addAgent(agent);
        }

        alert(id ? "Agent updated successfully!" : "Agent added successfully!");

        renderAgents();

    } catch (error) {
        console.error("Agent save error:", error);
        alert("Unable to save agent. Check the browser console.");
    }
}
function handleAgentAction(event) {
    const button = event.target.closest("button[data-action]");
    if (!button) return;

    const id = button.dataset.id;
    const action = button.dataset.action;

    const agent = getAgents().find(item => item.id === id);
    if (!agent) return;

    if (action === "edit") {
        showAgentForm(agent);
    }

    if (action === "view") {
        window.location.href =
            `agent-details.html?id=${encodeURIComponent(id)}`;
    }

    if (action === "delete") {
        if (confirm(`Delete ${agent.name}?`)) {
            deleteAgent(id);
            showNotification("Agent deleted successfully.");
            renderAgents();
        }
    }
}