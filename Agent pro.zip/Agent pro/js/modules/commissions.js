import {
    getAgents,
    getCommissions,
    saveCommissions
} from "../storage.js";

import {
    generateID,
    formatCurrency,
    formatDate,
    escapeHTML,
    showNotification
} from "../utils/helpers.js";

export function renderCommissions() {
    const commissions = getCommissions();

    const total = commissions.reduce(
        (sum, item) => sum + Number(item.amount || 0), 0
    );

    const paid = commissions
        .filter(item => item.status === "Paid")
        .reduce((sum, item) => sum + Number(item.amount || 0), 0);

    const pending = total - paid;

    document.getElementById("pageContent").innerHTML = `
        <div class="page-header">
            <div>
                <h1>Commission Management</h1>
                <p>Calculate and track agent commissions.</p>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <span>Total Commission</span>
                <h2>${formatCurrency(total)}</h2>
            </div>

            <div class="stat-card">
                <span>Paid</span>
                <h2>${formatCurrency(paid)}</h2>
            </div>

            <div class="stat-card">
                <span>Pending</span>
                <h2>${formatCurrency(pending)}</h2>
            </div>
        </div>

        <div class="panel">
            <h3>Add Commission</h3>

            <form id="commissionForm" class="form-grid">
                <label>Agent
                    <select id="commissionAgent" required>
                        <option value="">Select Agent</option>
                        ${getAgents().map(agent => `
                            <option value="${escapeHTML(agent.id)}">
                                ${escapeHTML(agent.name)}
                            </option>
                        `).join("")}
                    </select>
                </label>

                <label>Policy Number
                    <input type="text" id="policyNumber" required>
                </label>

                <label>Premium Amount (₹)
                    <input type="number" id="premiumAmount"
                        min="1" step="0.01" required>
                </label>

                <label>Commission Rate (%)
                    <input type="number" id="commissionRate"
                        min="0" max="100" step="0.1" value="10" required>
                </label>

                <button type="submit" class="btn-primary">
                    Calculate & Save
                </button>
            </form>
        </div>

        <div class="panel">
            <h3>Commission History</h3>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Policy</th>
                            <th>Agent</th>
                            <th>Premium</th>
                            <th>Rate</th>
                            <th>Commission</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody id="commissionTable"></tbody>
                </table>
            </div>
        </div>
    `;

    displayCommissions();

    document.getElementById("commissionForm")
        .addEventListener("submit", addCommission);

    document.getElementById("commissionTable")
        .addEventListener("click", handleCommissionAction);
}
function displayCommissions() {
    const commissions = getCommissions();
    const agents = getAgents();

    document.getElementById("commissionTable").innerHTML =
        commissions.length
        ? commissions.map(item => {

            // Match agent IDs even if their data types differ
            const agent = agents.find(a =>
                String(a.id).trim().toLowerCase() ===
                String(item.agentId).trim().toLowerCase()
            );

            const agentName = agent
                ? agent.name
                : item.agentName || "Agent not assigned";

            return `
                <tr>
                    <td>${escapeHTML(item.policyNumber)}</td>
                    <td>${escapeHTML(agentName)}</td>
                    <td>${formatCurrency(item.premium)}</td>
                    <td>${Number(item.rate)}%</td>
                    <td>${formatCurrency(item.amount)}</td>
                    <td>${escapeHTML(item.status)}</td>
                    <td>${formatDate(item.date)}</td>
                    <td>
                        ${
                            item.status === "Pending"
                            ? `<button class="btn-small"
                                data-action="paid"
                                data-id="${escapeHTML(item.id)}">
                                Mark Paid
                            </button>`
                            : "Completed"
                        }
                    </td>
                </tr>
            `;
        }).join("")
        : `<tr><td colspan="8">No commission records found.</td></tr>`;
}
function addCommission(event) {
    event.preventDefault();

    const agentId = document.getElementById("commissionAgent").value;
    const premium = Number(document.getElementById("premiumAmount").value);
    const rate = Number(document.getElementById("commissionRate").value);
    const policyNumber = document.getElementById("policyNumber").value.trim();

    const agents = getAgents();

    // Check whether the agent exists
    const agent = agents.find(item => item.id === agentId);

    if (!agent) {
        alert("Please select a registered agent.");
        return;
    }

    if (!policyNumber || premium <= 0 || rate < 0 || rate > 100) {
        alert("Please enter valid commission details.");
        return;
    }

    const commissions = getCommissions();

    if (commissions.some(item => item.policyNumber === policyNumber)) {
        alert("This policy number already exists.");
        return;
    }

    const amount = premium * rate / 100;

    commissions.push({
        id: generateID("COM"),
        agentId: agent.id,
        agentName: agent.name,
        policyNumber,
        premium,
        rate,
        amount,
        status: "Pending",
        date: new Date().toISOString(),
        paidDate: null
    });

    saveCommissions(commissions);

    alert("Commission added successfully!");

    renderCommissions();
}
function handleCommissionAction(event) {
    const button = event.target.closest("button[data-action='paid']");
    if (!button) return;

    const commissions = getCommissions();

    const commission = commissions.find(
        item => item.id === button.dataset.id
    );

    if (!commission) return;

    commission.status = "Paid";
    commission.paidDate = new Date().toISOString();

    saveCommissions(commissions);

    showNotification("Commission marked as paid.");
    renderCommissions();
}