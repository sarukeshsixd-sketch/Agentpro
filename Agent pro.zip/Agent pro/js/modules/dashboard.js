import {
    getAgents,
    getCommissions
} from "../storage.js";

import {
    formatCurrency,
    escapeHTML
} from "../utils/helpers.js";

let commissionChart = null;
let performanceChart = null;

export function renderDashboard() {
    const agents = getAgents();
    const commissions = getCommissions();

    const activeAgents = agents.filter(
        agent => agent.status === "Active"
    ).length;

    const totalCommission = commissions.reduce(
        (sum, item) => sum + Number(item.amount || 0),
        0
    );

    const totalPolicies = agents.reduce(
        (sum, agent) => sum + Number(agent.policiesSold || 0),
        0
    );

    const topAgents = [...agents]
        .sort((a, b) =>
            Number(b.policiesSold || 0) -
            Number(a.policiesSold || 0)
        )
        .slice(0, 5);

    document.getElementById("pageContent").innerHTML = `
        <div class="page-header">
            <div>
                <h1>Dashboard</h1>
                <p>Welcome to your AgentPro overview.</p>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <span>Total Agents</span>
                <h2>${agents.length}</h2>
                <p>Registered agents</p>
            </div>

            <div class="stat-card">
                <span>Active Agents</span>
                <h2>${activeAgents}</h2>
                <p>Currently active</p>
            </div>

            <div class="stat-card">
                <span>Total Commission</span>
                <h2>${formatCurrency(totalCommission)}</h2>
                <p>All recorded commissions</p>
            </div>

            <div class="stat-card">
                <span>Policies Sold</span>
                <h2>${totalPolicies}</h2>
                <p>Total policies sold</p>
            </div>
        </div>

        <div class="dashboard-grid">
            <div class="panel">
                <h3>Commission Overview</h3>
                <canvas id="commissionChart"></canvas>
            </div>

            <div class="panel">
                <h3>Agent Performance</h3>
                <canvas id="performanceChart"></canvas>
            </div>
        </div>

        <div class="panel">
            <h3>Top Performing Agents</h3>

            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Agent</th>
                            <th>Location</th>
                            <th>Policies Sold</th>
                            <th>Commission</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>
                        ${
                            topAgents.length
                            ? topAgents.map(agent => `
                                <tr>
                                    <td>${escapeHTML(agent.name)}</td>
                                    <td>${escapeHTML(agent.location || "-")}</td>
                                    <td>${Number(agent.policiesSold || 0)}</td>
                                    <td>${formatCurrency(agent.commission || 0)}</td>
                                    <td>${escapeHTML(agent.status || "-")}</td>
                                </tr>
                            `).join("")
                            : `<tr><td colspan="5">No agents available.</td></tr>`
                        }
                    </tbody>
                </table>
            </div>
        </div>
    `;

    renderCharts(agents, commissions);
}

function renderCharts(agents, commissions) {
    if (typeof Chart === "undefined") return;

    const commissionCanvas = document.getElementById("commissionChart");
    const performanceCanvas = document.getElementById("performanceChart");

    if (!commissionCanvas || !performanceCanvas) return;

    if (commissionChart) commissionChart.destroy();
    if (performanceChart) performanceChart.destroy();

    const pending = commissions
        .filter(item => item.status === "Pending")
        .reduce((sum, item) => sum + Number(item.amount || 0), 0);

    const paid = commissions
        .filter(item => item.status === "Paid")
        .reduce((sum, item) => sum + Number(item.amount || 0), 0);

    commissionChart = new Chart(commissionCanvas, {
        type: "doughnut",
        data: {
            labels: ["Paid", "Pending"],
            datasets: [{
                data: [paid, pending],
                backgroundColor: ["#F59E0B", "#FEF3C7"]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true
        }
    });

    const topAgents = [...agents]
        .sort((a, b) =>
            Number(b.policiesSold || 0) -
            Number(a.policiesSold || 0)
        )
        .slice(0, 5);

    performanceChart = new Chart(performanceCanvas, {
        type: "bar",
        data: {
            labels: topAgents.map(agent => agent.name),
            datasets: [{
                label: "Policies Sold",
                data: topAgents.map(agent =>
                    Number(agent.policiesSold || 0)
                ),
                backgroundColor: "#F59E0B"
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}