// =====================================
// AGENTPRO - FORM VALIDATION
// =====================================

export function validateEmail(email) {

    const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    return pattern.test(email);

}

export function validatePhone(phone) {

    const pattern = /^[6-9]\d{9}$/;

    return pattern.test(phone);

}

export function validatePassword(password) {

    return password.length >= 6;

}

export function validateRequired(value) {

    return String(value ?? "").trim().length > 0;

}

export function validateAgent(agent) {

    const errors = [];

    if (!validateRequired(agent.name)) {
        errors.push("Agent name is required.");
    }

    if (!validateEmail(agent.email)) {
        errors.push("Enter a valid email address.");
    }

    if (!validatePhone(agent.phone)) {
        errors.push("Enter a valid 10-digit Indian mobile number.");
    }

    if (!validateRequired(agent.location)) {
        errors.push("Location is required.");
    }

    return {
        valid: errors.length === 0,
        errors
    };

}