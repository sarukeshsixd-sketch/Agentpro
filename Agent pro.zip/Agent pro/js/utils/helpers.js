// =====================================
// AGENTPRO - HELPER FUNCTIONS
// =====================================

// Generate unique IDs
export function generateID(prefix = "AGT") {

    return prefix + Date.now().toString().slice(-8);

}

// Format currency
export function formatCurrency(amount) {

    return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        maximumFractionDigits: 0
    }).format(Number(amount) || 0);

}

// Format date
export function formatDate(date) {

    return new Date(date).toLocaleDateString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    });

}

// Calculate percentage
export function calculatePercentage(value, total) {

    if (!total) return 0;

    return Math.round((value / total) * 100);

}

// Get performance level
export function getPerformanceLevel(percentage) {

    if (percentage >= 100) return "Platinum";
    if (percentage >= 80) return "Gold";
    if (percentage >= 60) return "Silver";
    if (percentage >= 40) return "Bronze";

    return "Rising Star";

}

// Display notification
export function showNotification(message, type = "success") {

    const notification = document.createElement("div");

    notification.className = `notification ${type}`;

    notification.textContent = message;

    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 22px;
        background: ${type === "success" ? "#16A34A" : "#DC2626"};
        color: white;
        border-radius: 8px;
        z-index: 9999;
        box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);

}

// Escape HTML to prevent HTML injection
export function escapeHTML(value) {

    return String(value ?? "").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);

}