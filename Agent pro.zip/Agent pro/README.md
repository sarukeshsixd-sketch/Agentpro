
# AgentPro — Agent Management System

A frontend-only insurance agent management demo built with HTML, CSS and vanilla JavaScript modules.

## Run locally
1. Open this `AGENTPRO` folder in VS Code.
2. Install the **Live Server** extension.
3. Right-click `login.html` and choose **Open with Live Server**.
4. Sign in with `admin@agentpro.com` / `admin123`, or create a local demo account.

Do not open the HTML files directly with `file://`. The application loads sidebar, navbar and footer fragments with `fetch()`, so it needs a local web server.

## Included modules
- Dashboard metrics and agent leaderboard
- Agent create, view, update, delete, search and filtering
- Commission calculation and payment status tracking
- Performance target calculations
- Training program management
- Incentive program management
- CSV exports and print view
- Responsive layout and dark mode

## Data and limitations
The app stores demo records in browser `localStorage`. Data is local to the browser and device, can be cleared by the user, and is not shared between users. Authentication is a demonstration only: passwords are stored as plain text in local storage. Do not use this project to store real personal, financial, policyholder or insurance data. A production system requires a backend, secure authentication, authorization, validation, audit logging and a database.

The monthly chart is illustrative sample UI data; other dashboard summaries are calculated from the browser records.