export const initialIncentives = [
    {
        id: "INC001",
        title: "Top Performer Award",
        agentId: "AGT002",
        amount: 10000,
        date: "2026-10-30",
        createdAt: "2026-10-25"
    },
    {
        id: "INC002",
        title: "Sales Achievement Bonus",
        agentId: "AGT005",
        amount: 5000,
        date: "2026-10-28",
        createdAt: "2026-10-20"
    },
    {
        id: "INC003",
        title: "Customer Excellence Award",
        agentId: "AGT001",
        amount: 3000,
        date: "2026-10-25",
        createdAt: "2026-10-18"
    },
    {
        id: "INC004",
        title: "Monthly Target Achievement",
        agentId: "AGT003",
        amount: 2000,
        date: "2026-10-22",
        createdAt: "2026-10-15"
    }
];