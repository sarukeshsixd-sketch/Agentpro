export const initialCommissions = [
    {
        id: "COM001",
        agentId: "AGT001",
        policyNumber: "POL1001",
        premium: 50000,
        rate: 10,
        amount: 5000,
        status: "Paid",
        date: "2026-10-01",
        paidDate: "2026-10-05"
    },
    {
        id: "COM002",
        agentId: "AGT002",
        policyNumber: "POL1002",
        premium: 80000,
        rate: 10,
        amount: 8000,
        status: "Pending",
        date: "2026-10-04",
        paidDate: null
    },
    {
        id: "COM003",
        agentId: "AGT003",
        policyNumber: "POL1003",
        premium: 60000,
        rate: 10,
        amount: 6000,
        status: "Paid",
        date: "2026-10-08",
        paidDate: "2026-10-12"
    },
    {
        id: "COM004",
        agentId: "AGT004",
        policyNumber: "POL1004",
        premium: 40000,
        rate: 10,
        amount: 4000,
        status: "Pending",
        date: "2026-10-10",
        paidDate: null
    },
    {
        id: "COM005",
        agentId: "AGT005",
        policyNumber: "POL1005",
        premium: 100000,
        rate: 10,
        amount: 10000,
        status: "Paid",
        date: "2026-10-15",
        paidDate: "2026-10-18"
    },
    {
        id: "COM006",
        agentId: "AGT006",
        policyNumber: "POL1006",
        premium: 70000,
        rate: 10,
        amount: 7000,
        status: "Pending",
        date: "2026-10-20",
        paidDate: null
    }
];