export const initialTraining = [
    {
        id: "TRN001",
        title: "Insurance Fundamentals",
        description: "Introduction to insurance products, policies and basic concepts.",
        trainer: "Ramesh Kumar",
        date: "2026-11-20",
        createdAt: "2026-11-01"
    },
    {
        id: "TRN002",
        title: "Customer Relationship Management",
        description: "Learn customer communication, relationship building and customer retention.",
        trainer: "Priya Menon",
        date: "2026-11-25",
        createdAt: "2026-11-02"
    },
    {
        id: "TRN003",
        title: "Sales and Marketing Strategies",
        description: "Improve sales techniques, lead generation and policy conversion.",
        trainer: "Arun Raj",
        date: "2026-12-01",
        createdAt: "2026-11-05"
    },
    {
        id: "TRN004",
        title: "Digital Insurance Tools",
        description: "Understand digital platforms and tools used in insurance management.",
        trainer: "Karthik S",
        date: "2026-12-05",
        createdAt: "2026-11-07"
    }
];